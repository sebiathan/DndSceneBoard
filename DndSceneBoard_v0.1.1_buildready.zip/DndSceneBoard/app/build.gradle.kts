plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "de.dnd.sceneboard"
    compileSdk = 35

    defaultConfig {
        applicationId = "de.dnd.sceneboard"
        minSdk = 29
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.1"
    }
}

dependencies {
    implementation("androidx.activity:activity-ktx:1.9.3")
}
