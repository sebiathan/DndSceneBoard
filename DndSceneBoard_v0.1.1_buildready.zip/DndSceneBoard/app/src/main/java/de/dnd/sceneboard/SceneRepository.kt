package de.dnd.sceneboard

import android.content.Context
import org.json.JSONArray

class SceneRepository(context: Context) {
    private val prefs = context.getSharedPreferences("scene_board", Context.MODE_PRIVATE)

    fun load(): MutableList<Scene> {
        val raw = prefs.getString("scenes", null) ?: return mutableListOf(
            Scene(title = "Dungeon der Toten Drei", timePlan = "45 min")
        )
        return runCatching {
            val arr = JSONArray(raw)
            val list = MutableList(arr.length()) { i -> Scene.fromJson(arr.getJSONObject(i)) }
            if (list.isEmpty()) mutableListOf(Scene()) else list
        }.getOrElse { mutableListOf(Scene()) }
    }

    fun save(scenes: List<Scene>) {
        val arr = JSONArray().apply { scenes.forEach { put(it.toJson()) } }
        prefs.edit().putString("scenes", arr.toString()).apply()
    }
}
