package de.dnd.sceneboard

import android.content.Context
import android.graphics.*
import android.graphics.drawable.Drawable
import android.net.Uri
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import kotlin.math.max
import kotlin.math.min

class SceneCanvasView(context: Context) : View(context) {
    var scene: Scene? = null
        set(value) {
            field = value
            selected = null
            value?.let {
                cameraX = it.cameraX
                cameraY = it.cameraY
                scale = it.zoom.coerceIn(MIN_ZOOM, MAX_ZOOM)
            }
            bitmapCache.clear()
            invalidate()
        }

    var onSceneChanged: (() -> Unit)? = null
    var onElementDoubleTap: ((BoardElement) -> Unit)? = null

    private var cameraX = 0f
    private var cameraY = 0f
    private var scale = 1f
    private var selected: BoardElement? = null
    private var draggingElement = false
    private var resizingElement = false
    private var panning = false
    private var lastX = 0f
    private var lastY = 0f
    private val resizeHandleSizePx get() = 28f * resources.displayMetrics.density
    private val bitmapCache = mutableMapOf<String, Bitmap?>()

    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(224, 222, 228); strokeWidth = 1f }
    private val selectionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.rgb(103, 80, 164)
        strokeWidth = 3f
    }
    private val handlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(103, 80, 164) }
    private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(40, 38, 44); textSize = 18f }
    private val linkPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(20, 75, 160); textSize = 17f }
    private val cardPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val imagePlaceholderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(210, 210, 215) }

    private val gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDoubleTap(e: MotionEvent): Boolean {
            val p = screenToWorld(e.x, e.y)
            hitElement(p.x, p.y)?.let { onElementDoubleTap?.invoke(it) }
            return true
        }
    })

    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            val before = screenToWorld(detector.focusX, detector.focusY)
            scale = (scale * detector.scaleFactor).coerceIn(MIN_ZOOM, MAX_ZOOM)
            cameraX = before.x - (detector.focusX - width / 2f) / scale
            cameraY = before.y - (detector.focusY - height / 2f) / scale
            persistCamera()
            invalidate()
            return true
        }
    })

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(246, 244, 248))
        drawGrid(canvas)

        canvas.save()
        canvas.translate(width / 2f, height / 2f)
        canvas.scale(scale, scale)
        canvas.translate(-cameraX, -cameraY)

        scene?.elements?.forEach { drawElement(canvas, it) }
        selected?.let { drawSelection(canvas, it) }
        canvas.restore()
    }

    private fun drawGrid(canvas: Canvas) {
        val spacingWorld = 100f
        val spacingPx = spacingWorld * scale
        if (spacingPx < 18f) return

        val worldTopLeft = screenToWorld(0f, 0f)
        val worldBottomRight = screenToWorld(width.toFloat(), height.toFloat())
        val startX = kotlin.math.floor(worldTopLeft.x / spacingWorld).toInt() * spacingWorld
        val endX = kotlin.math.ceil(worldBottomRight.x / spacingWorld).toInt() * spacingWorld
        val startY = kotlin.math.floor(worldTopLeft.y / spacingWorld).toInt() * spacingWorld
        val endY = kotlin.math.ceil(worldBottomRight.y / spacingWorld).toInt() * spacingWorld

        var x = startX
        while (x <= endX) {
            val sx = worldToScreenX(x)
            canvas.drawLine(sx, 0f, sx, height.toFloat(), gridPaint)
            x += spacingWorld
        }
        var y = startY
        while (y <= endY) {
            val sy = worldToScreenY(y)
            canvas.drawLine(0f, sy, width.toFloat(), sy, gridPaint)
            y += spacingWorld
        }
    }

    private fun drawElement(canvas: Canvas, e: BoardElement) {
        val rect = RectF(e.x, e.y, e.x + e.width, e.y + e.height)
        when (e.type) {
            ElementType.NOTE -> {
                cardPaint.color = Color.rgb(255, 241, 153)
                canvas.drawRoundRect(rect, 16f, 16f, cardPaint)
                drawText(canvas, e.content, rect, textPaint, 18f)
            }
            ElementType.TEXT -> {
                cardPaint.color = Color.WHITE
                canvas.drawRoundRect(rect, 12f, 12f, cardPaint)
                drawText(canvas, e.content, rect, textPaint, 18f)
            }
            ElementType.LINK -> {
                cardPaint.color = Color.rgb(232, 240, 255)
                canvas.drawRoundRect(rect, 12f, 12f, cardPaint)
                drawText(canvas, "D&D Beyond / Link\n${e.content}", rect, linkPaint, 16f)
            }
            ElementType.IMAGE -> drawImage(canvas, e, rect)
        }
    }

    private fun drawImage(canvas: Canvas, e: BoardElement, rect: RectF) {
        val bitmap = bitmapCache.getOrPut(e.content) {
            runCatching {
                context.contentResolver.openInputStream(Uri.parse(e.content))?.use { BitmapFactory.decodeStream(it) }
            }.getOrNull()
        }
        if (bitmap == null) {
            canvas.drawRoundRect(rect, 12f, 12f, imagePlaceholderPaint)
            drawText(canvas, "Bild nicht verfügbar", rect, textPaint, 16f)
            return
        }
        val src = Rect(0, 0, bitmap.width, bitmap.height)
        canvas.drawBitmap(bitmap, src, rect, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
    }

    private fun drawText(canvas: Canvas, text: String, rect: RectF, paint: TextPaint, padding: Float) {
        val width = max(1, (rect.width() - padding * 2).toInt())
        val layout = StaticLayout.Builder.obtain(text, 0, text.length, paint, width)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setIncludePad(false)
            .setMaxLines(20)
            .build()
        canvas.save()
        canvas.clipRect(rect)
        canvas.translate(rect.left + padding, rect.top + padding)
        layout.draw(canvas)
        canvas.restore()
    }

    private fun drawSelection(canvas: Canvas, e: BoardElement) {
        val rect = RectF(e.x, e.y, e.x + e.width, e.y + e.height)
        selectionPaint.strokeWidth = 3f / scale
        canvas.drawRect(rect, selectionPaint)
        val handleWorld = resizeHandleSizePx / scale
        canvas.drawCircle(rect.right, rect.bottom, handleWorld / 2f, handlePaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        gestureDetector.onTouchEvent(event)
        scaleDetector.onTouchEvent(event)

        if (scaleDetector.isInProgress || event.pointerCount > 1) {
            draggingElement = false
            resizingElement = false
            panning = false
            return true
        }

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = event.x
                lastY = event.y
                val world = screenToWorld(event.x, event.y)
                val current = selected
                if (current != null && isOnResizeHandle(event.x, event.y, current)) {
                    resizingElement = true
                    parent?.requestDisallowInterceptTouchEvent(true)
                    return true
                }
                val hit = hitElement(world.x, world.y)
                if (hit != null) {
                    selected = hit
                    draggingElement = true
                    scene?.elements?.let { list ->
                        list.remove(hit)
                        list.add(hit)
                    }
                } else {
                    selected = null
                    panning = true
                }
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.x - lastX
                val dy = event.y - lastY
                when {
                    resizingElement -> selected?.let { e ->
                        e.width = max(MIN_ELEMENT_W, e.width + dx / scale)
                        e.height = max(MIN_ELEMENT_H, e.height + dy / scale)
                        onSceneChanged?.invoke()
                    }
                    draggingElement -> selected?.let { e ->
                        e.x += dx / scale
                        e.y += dy / scale
                        onSceneChanged?.invoke()
                    }
                    panning -> {
                        cameraX -= dx / scale
                        cameraY -= dy / scale
                        persistCamera()
                    }
                }
                lastX = event.x
                lastY = event.y
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (draggingElement || resizingElement) onSceneChanged?.invoke()
                draggingElement = false
                resizingElement = false
                panning = false
            }
        }
        return true
    }

    private fun hitElement(wx: Float, wy: Float): BoardElement? =
        scene?.elements?.asReversed()?.firstOrNull { wx in it.x..(it.x + it.width) && wy in it.y..(it.y + it.height) }

    private fun isOnResizeHandle(sx: Float, sy: Float, e: BoardElement): Boolean {
        val hx = worldToScreenX(e.x + e.width)
        val hy = worldToScreenY(e.y + e.height)
        val r = resizeHandleSizePx
        return sx in (hx - r)..(hx + r) && sy in (hy - r)..(hy + r)
    }

    fun addElement(type: ElementType, content: String, width: Float = 360f, height: Float = 220f) {
        val s = scene ?: return
        val e = BoardElement(
            type = type,
            x = cameraX - width / 2f,
            y = cameraY - height / 2f,
            width = width,
            height = height,
            content = content
        )
        s.elements += e
        selected = e
        onSceneChanged?.invoke()
        invalidate()
    }

    fun deleteSelected(): Boolean {
        val s = scene ?: return false
        val e = selected ?: return false
        s.elements.remove(e)
        selected = null
        onSceneChanged?.invoke()
        invalidate()
        return true
    }

    fun centerAll() {
        val els = scene?.elements.orEmpty()
        if (els.isEmpty()) {
            cameraX = 0f; cameraY = 0f; scale = 1f
            persistCamera(); invalidate(); return
        }
        val left = els.minOf { it.x }
        val top = els.minOf { it.y }
        val right = els.maxOf { it.x + it.width }
        val bottom = els.maxOf { it.y + it.height }
        cameraX = (left + right) / 2f
        cameraY = (top + bottom) / 2f
        val contentW = max(1f, right - left)
        val contentH = max(1f, bottom - top)
        val sx = width * 0.86f / contentW
        val sy = height * 0.82f / contentH
        scale = min(sx, sy).coerceIn(MIN_ZOOM, MAX_ZOOM)
        persistCamera(); invalidate()
    }

    private fun persistCamera() {
        scene?.apply {
            cameraX = this@SceneCanvasView.cameraX
            cameraY = this@SceneCanvasView.cameraY
            zoom = scale
        }
        onSceneChanged?.invoke()
    }

    private fun screenToWorld(sx: Float, sy: Float) = PointF(
        cameraX + (sx - width / 2f) / scale,
        cameraY + (sy - height / 2f) / scale
    )

    private fun worldToScreenX(wx: Float) = (wx - cameraX) * scale + width / 2f
    private fun worldToScreenY(wy: Float) = (wy - cameraY) * scale + height / 2f

    companion object {
        private const val MIN_ZOOM = 0.12f
        private const val MAX_ZOOM = 6f
        private const val MIN_ELEMENT_W = 120f
        private const val MIN_ELEMENT_H = 80f
    }
}
