package de.dnd.sceneboard

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

enum class ElementType { NOTE, TEXT, IMAGE, LINK }

data class BoardElement(
    val id: String = UUID.randomUUID().toString(),
    var type: ElementType,
    var x: Float,
    var y: Float,
    var width: Float,
    var height: Float,
    var content: String = ""
) {
    fun toJson() = JSONObject().apply {
        put("id", id)
        put("type", type.name)
        put("x", x.toDouble())
        put("y", y.toDouble())
        put("width", width.toDouble())
        put("height", height.toDouble())
        put("content", content)
    }

    companion object {
        fun fromJson(o: JSONObject) = BoardElement(
            id = o.optString("id", UUID.randomUUID().toString()),
            type = runCatching { ElementType.valueOf(o.optString("type", "TEXT")) }.getOrDefault(ElementType.TEXT),
            x = o.optDouble("x", 0.0).toFloat(),
            y = o.optDouble("y", 0.0).toFloat(),
            width = o.optDouble("width", 360.0).toFloat(),
            height = o.optDouble("height", 220.0).toFloat(),
            content = o.optString("content", "")
        )
    }
}

data class Scene(
    val id: String = UUID.randomUUID().toString(),
    var title: String = "Neue Szene",
    var timePlan: String = "30 min",
    var cameraX: Float = 0f,
    var cameraY: Float = 0f,
    var zoom: Float = 1f,
    val elements: MutableList<BoardElement> = mutableListOf()
) {
    fun toJson() = JSONObject().apply {
        put("id", id)
        put("title", title)
        put("timePlan", timePlan)
        put("cameraX", cameraX.toDouble())
        put("cameraY", cameraY.toDouble())
        put("zoom", zoom.toDouble())
        put("elements", JSONArray().apply { elements.forEach { put(it.toJson()) } })
    }

    companion object {
        fun fromJson(o: JSONObject): Scene {
            val list = mutableListOf<BoardElement>()
            val arr = o.optJSONArray("elements") ?: JSONArray()
            for (i in 0 until arr.length()) list += BoardElement.fromJson(arr.getJSONObject(i))
            return Scene(
                id = o.optString("id", UUID.randomUUID().toString()),
                title = o.optString("title", "Neue Szene"),
                timePlan = o.optString("timePlan", "30 min"),
                cameraX = o.optDouble("cameraX", 0.0).toFloat(),
                cameraY = o.optDouble("cameraY", 0.0).toFloat(),
                zoom = o.optDouble("zoom", 1.0).toFloat(),
                elements = list
            )
        }
    }
}
