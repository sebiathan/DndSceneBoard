package de.dnd.sceneboard

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {
    private lateinit var repo: SceneRepository
    private lateinit var scenes: MutableList<Scene>
    private var index = 0

    private lateinit var canvas: SceneCanvasView
    private lateinit var titleButton: Button
    private lateinit var timeButton: Button
    private lateinit var counter: TextView

    private val imagePicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            canvas.addElement(ElementType.IMAGE, uri.toString(), width = 460f, height = 300f)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo = SceneRepository(this)
        scenes = repo.load()
        setContentView(buildUi())
        showScene(0)
    }

    private fun buildUi(): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(23, 21, 27))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }
        val prev = Button(this).apply { text = "‹"; setOnClickListener { showScene(index - 1) } }
        val next = Button(this).apply { text = "›"; setOnClickListener { showScene(index + 1) } }
        titleButton = Button(this).apply {
            text = "Szene"
            setOnClickListener { editTitle() }
        }
        timeButton = Button(this).apply {
            text = "30 min"
            setOnClickListener { editTime() }
        }
        counter = TextView(this).apply {
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            textSize = 14f
        }
        val addScene = Button(this).apply { text = "+ Szene"; setOnClickListener { addScene() } }

        header.addView(prev, LinearLayout.LayoutParams(dp(52), dp(48)))
        header.addView(titleButton, LinearLayout.LayoutParams(0, dp(48), 1f))
        header.addView(timeButton, LinearLayout.LayoutParams(dp(110), dp(48)))
        header.addView(counter, LinearLayout.LayoutParams(dp(64), dp(48)))
        header.addView(next, LinearLayout.LayoutParams(dp(52), dp(48)))
        header.addView(addScene, LinearLayout.LayoutParams(dp(100), dp(48)))
        root.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(60)))

        canvas = SceneCanvasView(this).apply {
            onSceneChanged = { save() }
            onElementDoubleTap = { element ->
                when (element.type) {
                    ElementType.LINK -> openLink(element.content)
                    ElementType.NOTE, ElementType.TEXT -> editElement(element)
                    ElementType.IMAGE -> Unit
                }
            }
        }
        root.addView(canvas, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val tools = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(4), dp(6), dp(4))
        }
        fun tool(label: String, action: () -> Unit) = Button(this).apply {
            text = label
            textSize = 12f
            setOnClickListener { action() }
        }
        tools.addView(tool("Notiz") { addTextElement(ElementType.NOTE) }, weighted())
        tools.addView(tool("Text") { addTextElement(ElementType.TEXT) }, weighted())
        tools.addView(tool("Bild") { imagePicker.launch(arrayOf("image/*")) }, weighted())
        tools.addView(tool("Link") { addLink() }, weighted())
        tools.addView(tool("Alles") { canvas.centerAll() }, weighted())
        tools.addView(tool("Löschen") {
            if (!canvas.deleteSelected()) toast("Erst ein Element auswählen")
        }, weighted())
        root.addView(tools, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(64)))
        return root
    }

    private fun weighted() = LinearLayout.LayoutParams(0, dp(54), 1f).apply { marginStart = dp(2); marginEnd = dp(2) }

    private fun showScene(newIndex: Int) {
        if (scenes.isEmpty()) scenes += Scene()
        index = newIndex.coerceIn(0, scenes.lastIndex)
        val s = scenes[index]
        titleButton.text = s.title
        timeButton.text = s.timePlan
        counter.text = "${index + 1}/${scenes.size}"
        canvas.scene = s
    }

    private fun addScene() {
        scenes += Scene(title = "Szene ${scenes.size + 1}", timePlan = "30 min")
        save()
        showScene(scenes.lastIndex)
    }

    private fun editTitle() = inputDialog("Szenentitel", scenes[index].title) { value ->
        scenes[index].title = value.ifBlank { "Unbenannte Szene" }
        save(); showScene(index)
    }

    private fun editTime() = inputDialog("Zeitplanung", scenes[index].timePlan) { value ->
        scenes[index].timePlan = value.ifBlank { "—" }
        save(); showScene(index)
    }

    private fun addTextElement(type: ElementType) {
        inputDialog(if (type == ElementType.NOTE) "Neue Notiz" else "Neuer Text", "") { value ->
            if (value.isNotBlank()) canvas.addElement(type, value)
        }
    }

    private fun editElement(element: BoardElement) {
        inputDialog("Inhalt bearbeiten", element.content) { value ->
            element.content = value
            save(); canvas.invalidate()
        }
    }

    private fun addLink() {
        val input = EditText(this).apply {
            hint = "https://www.dndbeyond.com/..."
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setSelectAllOnFocus(false)
        }
        AlertDialog.Builder(this)
            .setTitle("D&D-Beyond-Link")
            .setView(input)
            .setPositiveButton("Hinzufügen") { _, _ ->
                val value = input.text.toString().trim()
                if (value.isNotBlank()) canvas.addElement(ElementType.LINK, value, 440f, 150f)
            }
            .setNegativeButton("Abbrechen", null)
            .show()
    }

    private fun openLink(raw: String) {
        val normalized = if (raw.startsWith("http://") || raw.startsWith("https://")) raw else "https://$raw"
        runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(normalized))) }
            .onFailure { toast("Link konnte nicht geöffnet werden") }
    }

    private fun inputDialog(title: String, current: String, onDone: (String) -> Unit) {
        val input = EditText(this).apply {
            setText(current)
            setSelection(text.length)
            minLines = 1
            maxLines = 8
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(input)
            .setPositiveButton("Speichern") { _, _ -> onDone(input.text.toString()) }
            .setNegativeButton("Abbrechen", null)
            .show()
    }

    private fun save() = repo.save(scenes)

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
